"""Symptom triage starter. Not a trained image or disease classifier."""
from al_fares_agri.schemas import DiagnosisRequest, DiagnosisResponse


def triage_symptoms(req: DiagnosisRequest) -> DiagnosisResponse:
    text = req.symptoms.casefold()
    causes: list[str] = []
    if any(word in text for word in ("yellow", "اصفر", "اصفرار")):
        causes.extend([
            "نقص أو اختلال تغذية (يحتاج فحص نمط الاصفرار وتحليل التربة/الأنسجة)",
            "إجهاد مائي أو ملوحة أو مشكلة جذور",
            "مرض أو آفة محتملة بحسب شكل البقع وتوزعها",
        ])
    elif any(word in text for word in ("rust", "صدأ")):
        causes.append("اشتباه بمرض صدأ؛ يلزم تصوير البثرات وفحص مختص لتحديد النوع.")
    else:
        causes.append("الأعراض غير كافية لتحديد سبب مرجح؛ يلزم وصف وصور أوضح.")
    return DiagnosisResponse(
        crop=req.crop,
        possible_causes=causes,
        next_steps=[
            "التقط صوراً قريبة للورقة وصورة كاملة للنبات وصورة عامة للحقل.",
            "اذكر عمر النبات وتاريخ ظهور الأعراض ونسبة النباتات المتأثرة.",
            "افحص جذور عينة من النباتات وقارنها بنباتات سليمة.",
            "لا تستخدم مبيداً قبل تأكيد الآفة أو المرض والتحقق من تسجيل المنتج محلياً.",
        ],
        confidence="not_assessed",
        disclaimer="هذا فرز أولي للنص وليس تشخيصاً مخبرياً أو نموذج رؤية مدرّباً."
    )
