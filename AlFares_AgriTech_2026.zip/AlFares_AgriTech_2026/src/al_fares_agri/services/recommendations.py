"""Conservative, explainable agronomic screening rules.

This module intentionally avoids fertilizer/pesticide rates without laboratory
results, field history, irrigation/water quality, cultivar and local validation.
"""
from al_fares_agri.schemas import RecommendationRequest, RecommendationResponse

DISCLAIMER = (
    "هذه إرشادات فرز أولي وليست وصفة تسميد أو مبيد. يلزم تحليل تربة ومياه "
    "ومراجعة مهندس زراعي محلي قبل اتخاذ قرار تطبيقي."
)


def build_recommendation(req: RecommendationRequest) -> RecommendationResponse:
    missing: list[str] = []
    if not req.soil_test_available:
        missing.append("تحليل تربة حديث يشمل pH وEC والمادة العضوية والعناصر الغذائية")
    if req.soil_ec_ds_m is None:
        missing.append("قياس ملوحة التربة EC")
    if req.soil_ph is None:
        missing.append("قياس pH")
    advice = [
        "سجّل تاريخ الزراعة والصنف والمحصول السابق وطريقة الري أو كمية الأمطار.",
        "افحص الحقل ميدانياً في عدة نقاط، ولا تعتمد على صورة واحدة لتقدير كامل القطعة.",
        "قارن حالة النباتات السليمة والمتأثرة، وصوّر الأعراض مع ذكر تاريخ ظهورها.",
    ]
    if req.crop in ("wheat", "barley"):
        advice.append("في الحبوب، راقب كثافة التفريع والصدأ والتبقعات والحشائش بحسب مرحلة النمو.")
    else:
        advice.append("في القطن، راقب البادرات والحشرات واللوز وسجّل تعداد الآفة قبل أي مكافحة.")
    if req.soil_test_available and req.soil_ph is not None and req.soil_ec_ds_m is not None:
        status = "screening_only"
        advice.append("تم إدخال بعض نتائج التربة؛ يلزم استكمال بيانات N-P-K والقوام والمياه قبل حساب الاحتياجات.")
    else:
        status = "needs_lab_test"
        advice.append("لا يمكن تحديد نوع السماد أو جرعته بأمان من اسم المحصول والمنطقة فقط.")
    return RecommendationResponse(
        crop=req.crop, region=req.region, stage=req.stage, status=status,
        advice=advice, missing_data=missing, disclaimer=DISCLAIMER
    )
