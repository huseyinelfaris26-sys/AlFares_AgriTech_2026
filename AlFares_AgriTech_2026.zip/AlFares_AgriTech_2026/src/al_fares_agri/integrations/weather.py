"""Weather-provider boundary. Real provider calls will be added with tests."""
from dataclasses import dataclass


@dataclass(frozen=True)
class WeatherStatus:
    provider: str
    connected: bool
    message: str


def provider_status() -> WeatherStatus:
    """Do not fabricate forecasts: report that provider integration is pending."""
    return WeatherStatus(
        provider="Open-Meteo (planned)",
        connected=False,
        message="لم يتم جلب توقعات مباشرة. يلزم تنفيذ موصل الشبكة وإضافة اختبارات التكامل."
    )
