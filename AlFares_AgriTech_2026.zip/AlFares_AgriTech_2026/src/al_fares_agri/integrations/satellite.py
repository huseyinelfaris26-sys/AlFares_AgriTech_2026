"""Satellite data-provider boundary; no imagery is fetched in this starter."""
from dataclasses import dataclass


@dataclass(frozen=True)
class SatelliteStatus:
    providers: tuple[str, ...]
    connected: bool
    message: str


def provider_status() -> SatelliteStatus:
    return SatelliteStatus(
        providers=("Copernicus Sentinel-1", "Copernicus Sentinel-2", "Landsat"),
        connected=False,
        message="مصادر مخططة فقط؛ لم يتم تنزيل أو تحليل أي مشهد فضائي بعد."
    )
