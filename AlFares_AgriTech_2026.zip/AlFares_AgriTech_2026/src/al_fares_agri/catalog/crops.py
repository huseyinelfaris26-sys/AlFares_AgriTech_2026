"""Initial crop catalogue; expand only with cited local agronomic references."""
CROPS = {
    "wheat": {
        "name_ar": "القمح",
        "scientific_name": "Triticum aestivum / Triticum durum",
        "stages": ["emergence", "tillering", "stem_elongation", "heading", "flowering", "grain_filling", "maturity"],
    },
    "barley": {
        "name_ar": "الشعير",
        "scientific_name": "Hordeum vulgare",
        "stages": ["emergence", "tillering", "stem_elongation", "heading", "grain_filling", "maturity"],
    },
    "cotton": {
        "name_ar": "القطن",
        "scientific_name": "Gossypium hirsutum",
        "stages": ["emergence", "squaring", "flowering", "boll_formation", "boll_opening", "harvest"],
    },
}
