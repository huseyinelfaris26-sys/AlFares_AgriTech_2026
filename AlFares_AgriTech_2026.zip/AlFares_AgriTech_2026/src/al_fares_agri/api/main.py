"""FastAPI application entry point."""
from fastapi import FastAPI
from al_fares_agri import __version__
from al_fares_agri.config import get_settings
from al_fares_agri.schemas import (
    RecommendationRequest, RecommendationResponse, DiagnosisRequest, DiagnosisResponse
)
from al_fares_agri.services.recommendations import build_recommendation
from al_fares_agri.services.diagnosis import triage_symptoms
from al_fares_agri.integrations.weather import provider_status as weather_status
from al_fares_agri.integrations.satellite import provider_status as satellite_status

settings = get_settings()
app = FastAPI(title=settings.app_name, version=__version__)


@app.get("/health")
def health() -> dict[str, str]:
    """Liveness endpoint for cloud health checks."""
    return {"status": "ok", "version": __version__}


@app.get("/api/v1/crops")
def list_crops() -> dict:
    from al_fares_agri.catalog.crops import CROPS
    return CROPS


@app.post("/api/v1/recommendations", response_model=RecommendationResponse)
def recommendations(request: RecommendationRequest) -> RecommendationResponse:
    return build_recommendation(request)


@app.post("/api/v1/diagnosis/triage", response_model=DiagnosisResponse)
def diagnosis(request: DiagnosisRequest) -> DiagnosisResponse:
    return triage_symptoms(request)


@app.get("/api/v1/integrations/status")
def integrations() -> dict:
    return {
        "weather": weather_status().__dict__,
        "satellite": satellite_status().__dict__,
    }
