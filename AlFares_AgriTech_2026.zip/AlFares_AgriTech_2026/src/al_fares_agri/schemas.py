"""Shared request/response schemas with input validation."""
from typing import Literal
from pydantic import BaseModel, Field

CropName = Literal["wheat", "barley", "cotton"]
RegionName = Literal["tal_abyad", "raqqa"]


class RecommendationRequest(BaseModel):
    crop: CropName
    region: RegionName
    stage: str = Field(min_length=2, max_length=40)
    soil_ph: float | None = Field(default=None, ge=0, le=14)
    soil_ec_ds_m: float | None = Field(default=None, ge=0, le=100)
    soil_test_available: bool = False


class DiagnosisRequest(BaseModel):
    crop: CropName
    symptoms: str = Field(min_length=3, max_length=1000)


class RecommendationResponse(BaseModel):
    crop: str
    region: str
    stage: str
    status: Literal["screening_only", "needs_lab_test"]
    advice: list[str]
    missing_data: list[str]
    disclaimer: str


class DiagnosisResponse(BaseModel):
    crop: str
    possible_causes: list[str]
    next_steps: list[str]
    confidence: Literal["not_assessed"]
    disclaimer: str
