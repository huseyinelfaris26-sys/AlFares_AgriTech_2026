"""Command-line interface for local operation and automation."""
import typer
from al_fares_agri import __version__
from al_fares_agri.catalog.crops import CROPS
from al_fares_agri.schemas import RecommendationRequest, DiagnosisRequest
from al_fares_agri.services.recommendations import build_recommendation
from al_fares_agri.services.diagnosis import triage_symptoms

app = typer.Typer(help="الفارس لتقنيات الزراعة المتطورة 2026")


@app.command()
def info() -> None:
    """Show product identity and version."""
    typer.echo(f"Al-Fares Advanced Agricultural Technologies 2026 v{__version__}")


@app.command()
def crops() -> None:
    """List supported crops."""
    for key, value in CROPS.items():
        typer.echo(f"{key}: {value['name_ar']} ({value['scientific_name']})")


@app.command()
def recommend(
    crop: str = typer.Option(..., help="wheat, barley, cotton"),
    region: str = typer.Option(..., help="tal_abyad or raqqa"),
    stage: str = typer.Option(..., help="Crop growth stage"),
) -> None:
    """Generate cautious first-pass crop guidance."""
    result = build_recommendation(RecommendationRequest(crop=crop, region=region, stage=stage))
    typer.echo(result.model_dump_json(indent=2))


@app.command()
def diagnose(
    crop: str = typer.Option(..., help="wheat, barley, cotton"),
    symptom: str = typer.Option(..., help="Describe visible symptoms"),
) -> None:
    """Triage a text description; this is not image diagnosis."""
    result = triage_symptoms(DiagnosisRequest(crop=crop, symptoms=symptom))
    typer.echo(result.model_dump_json(indent=2))
