from fastapi.testclient import TestClient
from al_fares_agri.api.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_crop_catalog():
    response = client.get("/api/v1/crops")
    assert response.status_code == 200
    assert {"wheat", "barley", "cotton"} <= set(response.json())


def test_recommendation_requires_lab_data():
    response = client.post("/api/v1/recommendations", json={
        "crop": "wheat", "region": "raqqa", "stage": "tillering"
    })
    assert response.status_code == 200
    assert response.json()["status"] == "needs_lab_test"
    assert response.json()["missing_data"]


def test_diagnosis_triage():
    response = client.post("/api/v1/diagnosis/triage", json={
        "crop": "wheat", "symptoms": "yellow leaves"
    })
    assert response.status_code == 200
    assert response.json()["confidence"] == "not_assessed"
